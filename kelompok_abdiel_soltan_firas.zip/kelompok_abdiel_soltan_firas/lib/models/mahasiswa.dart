// models/mahasiswa.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class Mahasiswa {
  final String nama;
  final String nim;
  final String tglLahir;
  final String hobi;
  final String nomorHp;
  final String alamat;

  Mahasiswa({
    required this.nama,
    required this.nim,
    required this.tglLahir,
    required this.hobi,
    required this.nomorHp,
    required this.alamat,
  });

  // Mengubah Map (dari Firestore) menjadi objek Mahasiswa
  factory Mahasiswa.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Mahasiswa(
      nama: data['nama'] ?? '',
      nim: data['nim'] ?? '',
      tglLahir: data['tglLahir'] ?? '',
      hobi: data['hobi'] ?? '',
      nomorHp: data['nomorHp'] ?? '',
      alamat: data['alamat'] ?? '',
    );
  }

  // Mengubah objek Mahasiswa menjadi Map (untuk dikirim ke Firestore)
  Map<String, dynamic> toMap() {
    return {
      'nama': nama,
      'nim': nim,
      'tglLahir': tglLahir,
      'hobi': hobi,
      'nomorHp': nomorHp,
      'alamat': alamat,
    };
  }
}