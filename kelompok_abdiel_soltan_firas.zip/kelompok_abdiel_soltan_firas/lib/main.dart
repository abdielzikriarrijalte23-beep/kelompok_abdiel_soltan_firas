// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart'; // File penting dari flutterfire

//
// 1. INI SOLUSI UNTUK ERROR ANDA: Tambahkan import untuk semua layar
//
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/add_edit_screen.dart';
import 'screens/about_screen.dart';

void main() async {
  //
  // 2. INI FUNGSI main() YANG BENAR (JANGAN DIUBAH LAGI)
  //
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter CRUD Firebase',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home sekarang sudah benar karena SplashScreen sudah di-import
      home: SplashScreen(),
      
      // rute juga sekarang sudah benar
      routes: {
        '/login': (context) => LoginScreen(),
        '/dashboard': (context) => DashboardScreen(),
        '/addEdit': (context) => AddEditScreen(),
        '/about': (context) => AboutScreen(),
      },
    );
  }
}