// screens/add_edit_screen.dart
import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/mahasiswa.dart';

class AddEditScreen extends StatefulWidget {
  @override
  _AddEditScreenState createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dbService = DatabaseService();

  // Controllers untuk setiap field
  final _namaController = TextEditingController();
  final _nimController = TextEditingController();
  final _tglLahirController = TextEditingController();
  final _hobiController = TextEditingController();
  final _nomorHpController = TextEditingController();
  final _alamatController = TextEditingController();

  String? userId;
  String? docId;
  Mahasiswa? initialData;
  bool isEditMode = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Ambil arguments
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    if (args != null) {
      userId = args['userId'];
      docId = args['docId']; // Akan null jika mode 'Add'
      initialData = args['mahasiswa']; // Akan null jika mode 'Add'

      if (docId != null && initialData != null) {
        // Ini adalah mode EDIT
        isEditMode = true;
        _namaController.text = initialData!.nama;
        _nimController.text = initialData!.nim;
        _tglLahirController.text = initialData!.tglLahir;
        _hobiController.text = initialData!.hobi;
        _nomorHpController.text = initialData!.nomorHp;
        _alamatController.text = initialData!.alamat;
      }
    }
  }

  @override
  void dispose() {
    // Bersihkan controllers
    _namaController.dispose();
    _nimController.dispose();
    _tglLahirController.dispose();
    _hobiController.dispose();
    _nomorHpController.dispose();
    _alamatController.dispose();
    super.dispose();
  }

  void _submitData() async {
    if (_formKey.currentState!.validate()) {
      if (userId == null) return; // Seharusnya tidak terjadi

      Mahasiswa mahasiswa = Mahasiswa(
        nama: _namaController.text,
        nim: _nimController.text,
        tglLahir: _tglLahirController.text,
        hobi: _hobiController.text,
        nomorHp: _nomorHpController.text,
        alamat: _alamatController.text,
      );

      try {
        if (isEditMode) {
          // UPDATE
          await _dbService.updateMahasiswa(userId!, docId!, mahasiswa);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Data berhasil diperbarui')),
          );
        } else {
          // CREATE
          await _dbService.addMahasiswa(userId!, mahasiswa);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Data berhasil ditambahkan')),
          );
        }
        Navigator.of(context).pop(); // Kembali ke Dashboard
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal menyimpan data: $e')),
        );
      }
    }
  }

  // Helper untuk membuat TextFormField
  Widget _buildTextFormField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label tidak boleh kosong';
        }
        return null;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditMode ? 'Edit Data Mahasiswa' : 'Tambah Data Mahasiswa'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildTextFormField(_namaController, 'Nama Mahasiswa'),
              SizedBox(height: 10),
              _buildTextFormField(_nimController, 'NIM'),
              SizedBox(height: 10),
              _buildTextFormField(_tglLahirController, 'Tanggal Lahir (DD-MM-YYYY)'),
              SizedBox(height: 10),
              _buildTextFormField(_hobiController, 'Hobi'),
              SizedBox(height: 10),
              _buildTextFormField(_nomorHpController, 'Nomor HP'),
              SizedBox(height: 10),
              _buildTextFormField(_alamatController, 'Alamat'),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitData,
                child: Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}