// screens/login_screen.dart
import 'package:flutter/material.dart';
// BARU: Import Firestore untuk bisa melakukan pengecekan
import 'package:cloud_firestore/cloud_firestore.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userIdController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  // BARU: Variabel untuk mengelola status loading
  bool _isLoading = false;

  // BARU: Ubah fungsi _login menjadi async untuk menunggu pengecekan Firebase
  void _login() async {
    if (_formKey.currentState!.validate()) {
      // 1. Tampilkan loading
      setState(() {
        _isLoading = true;
      });

      String userId = _userIdController.text.trim(); // .trim() untuk hapus spasi

      try {
        // 2. Lakukan pengecekan ke Firestore
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .get();

        // 3. Cek apakah dokumen user ada
        if (doc.exists) {
          // JIKA ADA: User valid, pindah ke Dashboard
          if (mounted) { // Pastikan widget masih ada
            Navigator.of(context).pushReplacementNamed(
              '/dashboard',
              arguments: userId,
            );
          }
        } else {
          // JIKA TIDAK ADA: User tidak valid, tampilkan error
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('User ID tidak terdaftar atau salah.')),
            );
          }
        }
      } catch (e) {
        // Handle jika ada error koneksi/lainnya
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: Gagal terhubung ke server.')),
          );
        }
      }

      // 4. Hentikan loading
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Masukkan User ID',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _userIdController,
                decoration: InputDecoration(
                  labelText: 'User ID',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'User ID tidak boleh kosong';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // BARU: Tampilkan loading atau tombol
              _isLoading
                  ? CircularProgressIndicator() // Tampilkan loading
                  : ElevatedButton(
                      onPressed: _login,
                      child: Text('Masuk'),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}