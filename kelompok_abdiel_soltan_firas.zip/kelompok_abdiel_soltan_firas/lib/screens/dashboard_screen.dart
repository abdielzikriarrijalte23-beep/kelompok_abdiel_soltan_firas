// screens/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/database_service.dart';
import '../models/mahasiswa.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final DatabaseService _dbService = DatabaseService();
  String? userId; // Variabel untuk menyimpan userID

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Ambil userID dari arguments yang dikirim dari LoginScreen
    final args = ModalRoute.of(context)!.settings.arguments;
    if (args != null) {
      userId = args as String;
    } else {
      // Handle jika tidak ada userID (misalnya, kembali ke login)
      Navigator.of(context).pushReplacementNamed('/login');
    }
  }

  void _navigateToAbout() {
    Navigator.of(context).pushNamed('/about');
  }

  void _navigateToAddScreen() {
    // Kirim userID ke AddEditScreen
    Navigator.of(context).pushNamed('/addEdit', arguments: {'userId': userId});
  }

  void _navigateToEditScreen(String docId, Mahasiswa mahasiswa) {
    // Kirim userID, docId, dan data mahasiswa ke AddEditScreen
    Navigator.of(context).pushNamed(
      '/addEdit',
      arguments: {
        'userId': userId,
        'docId': docId,
        'mahasiswa': mahasiswa,
      },
    );
  }

  void _deleteData(String docId) async {
    if (userId == null) return;
    try {
      await _dbService.deleteMahasiswa(userId!, docId);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Data berhasil dihapus')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menghapus data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (userId == null) {
      // Tampilkan loading atau widget kosong sementara userId belum siap
      return Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard Mahasiswa (User: $userId)'),
        actions: [
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: _navigateToAbout,
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _dbService.getMahasiswaStream(userId!),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('Belum ada data mahasiswa.'));
          }

          // Jika ada data, tampilkan dalam ListView
          return ListView(
            padding: EdgeInsets.all(8.0),
            children: snapshot.data!.docs.map((DocumentSnapshot document) {
              Mahasiswa mahasiswa = Mahasiswa.fromFirestore(document);
              String docId = document.id;

              return Card(
                margin: EdgeInsets.symmetric(vertical: 8.0),
                child: ListTile(
                  title: Text(mahasiswa.nama, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('NIM: ${mahasiswa.nim}'),
                      Text('Tgl Lahir: ${mahasiswa.tglLahir}'),
                      Text('Hobi: ${mahasiswa.hobi}'),
                      Text('No HP: ${mahasiswa.nomorHp}'),
                      Text('Alamat: ${mahasiswa.alamat}'),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Tombol EDIT
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _navigateToEditScreen(docId, mahasiswa),
                      ),
                      // Tombol DELETE
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteData(docId),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddScreen,
        child: Icon(Icons.add),
        tooltip: 'Tambah Data',
      ),
    );
  }
}