// services/database_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/mahasiswa.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Mendapatkan collection reference untuk data mahasiswa berdasarkan userID
  CollectionReference _getMahasiswaCollection(String userId) {
    return _firestore.collection('users').doc(userId).collection('mahasiswa');
  }

  // CREATE
Future<void> addMahasiswa(String userId, Mahasiswa mahasiswa) {
  // Ambil nama mahasiswa dari objek
  String namaMahasiswa = mahasiswa.nama; 

  // Gunakan nama itu sebagai ID Dokumen
  return _getMahasiswaCollection(userId)
      .doc(namaMahasiswa) // <-- Mengatur ID kustom (nama)
      .set(mahasiswa.toMap()); // <-- Menyimpan data
  }

  // READ (Stream untuk Realtime Update)
  Stream<QuerySnapshot> getMahasiswaStream(String userId) {
    return _getMahasiswaCollection(userId).snapshots();
  }

  // UPDATE
  Future<void> updateMahasiswa(String userId, String docId, Mahasiswa mahasiswa) {
    return _getMahasiswaCollection(userId).doc(docId).update(mahasiswa.toMap());
  }

  // DELETE
  Future<void> deleteMahasiswa(String userId, String docId) {
    return _getMahasiswaCollection(userId).doc(docId).delete();
  }
}